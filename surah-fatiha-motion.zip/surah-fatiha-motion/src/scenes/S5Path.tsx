import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { SceneProps } from "../types";
import { Arabic, Bangla, KeywordPill, SceneShell, Sfx, clamp01, useSpring } from "../components/common";

// Timeline/Path: সরল আলোর পথ + কম্পাস
const VP = { x: 480, y: 300 };

const Path: React.FC = () => {
  const frame = useCurrentFrame();
  const pIn = useSpring(0, theme.spring.smooth);
  const needleP = useSpring(10, theme.spring.bouncy);
  const needle = interpolate(needleP, [0, 1], [-150, 0]) + Math.sin(frame / 28) * 2;
  const N = 9;
  const dashes = Array.from({ length: N }).map((_, i) => {
    const t = (((i + frame * 0.04) % N) / N);
    const y = VP.y + 620 * Math.pow(t, 1.8);
    return { y, w: 6 + 34 * t, l: 10 + 90 * t, o: Math.min(1, t * 2.4) };
  });
  const L = { x: 110, y: 920 }, R = { x: 850, y: 920 };
  return (
    <svg width={960} height={940} viewBox="0 0 960 940" style={{ opacity: pIn }}>
      <defs>
        <linearGradient id="g5-road" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0%" stopColor={theme.colors.hero} stopOpacity={0.85} />
          <stop offset="100%" stopColor={theme.colors.hero} stopOpacity={0.05} />
        </linearGradient>
        <radialGradient id="g5-halo" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor={theme.colors.accent} stopOpacity={0.55} />
          <stop offset="100%" stopColor={theme.colors.accent} stopOpacity={0} />
        </radialGradient>
        <clipPath id="g5-clip"><rect x={0} y={0} width={960} height={interpolate(pIn, [0, 1], [300, 940], clamp01)} /></clipPath>
      </defs>
      <g style={{ filter: `drop-shadow(0 0 40px ${theme.colors.glow})` }}>
        <polygon points={`${L.x},${L.y} ${VP.x},${VP.y} ${R.x},${R.y}`} fill="url(#g5-road)" />
      </g>
      <line x1={L.x} y1={L.y} x2={VP.x} y2={VP.y} stroke={theme.colors.accent} strokeWidth={4} strokeOpacity={0.8} />
      <line x1={R.x} y1={R.y} x2={VP.x} y2={VP.y} stroke={theme.colors.accent} strokeWidth={4} strokeOpacity={0.8} />
      {dashes.map((d, i) => (
        <rect key={i} x={VP.x - d.w / 2} y={d.y} width={d.w} height={d.l} rx={d.w / 2} fill={theme.colors.text} opacity={d.o * 0.9} />
      ))}
      {/* কম্পাস */}
      <circle cx={VP.x} cy={VP.y - 60} r={170 + Math.sin(frame / 22) * 6} fill="url(#g5-halo)" />
      <g transform={`translate(${VP.x} ${VP.y - 60}) scale(${needleP > 1 ? 1 : needleP})`}>
        <circle r={86} fill={theme.colors.bgDeep} fillOpacity={0.8} stroke={theme.colors.accent} strokeWidth={6} />
        {[0, 90, 180, 270].map((d) => (
          <line key={d} x1={0} y1={-86} x2={0} y2={-68} stroke={theme.colors.accent} strokeWidth={5} strokeLinecap="round" transform={`rotate(${d})`} />
        ))}
        <g transform={`rotate(${needle})`}>
          <polygon points="0,-66 15,0 -15,0" fill={theme.colors.accent} />
          <polygon points="0,66 15,0 -15,0" fill={theme.colors.muted} />
        </g>
        <circle r={9} fill={theme.colors.text} />
      </g>
    </svg>
  );
};

export const S5Path: React.FC<SceneProps> = ({ cues }) => {
  const cue = cues[0];
  return (
    <SceneShell glowX={74} glowY={40} glowColor={theme.colors.hero}>
      <Sfx name="pop" at={4} rate={0.96} />
      <Sfx name="chime" at={14} rate={1.1} />
      <Sfx name="click" at={44} />
      <div style={{ position: "absolute", left: 100, top: 0, bottom: 0, width: 860, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", gap: 18 }}>
        <KeywordPill text={cue.keyword ?? ""} delay={12} />
        <Arabic text={cue.arabic} size={theme.size.arabicHero} delay={0} maxWidth={860} />
        <Bangla text={cue.bangla} size={theme.size.bnHero + 4} delay={14} maxWidth={860} accent={[1, 2]} hlDelay={44} />
      </div>
      <div style={{ position: "absolute", left: 900, top: 70 }}><Path /></div>
    </SceneShell>
  );
};
