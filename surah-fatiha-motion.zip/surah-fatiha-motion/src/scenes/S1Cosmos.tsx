import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { SceneProps } from "../types";
import { Arabic, Bangla, Entrance, KeywordPill, SceneShell, Sfx, clamp01, useSpring } from "../components/common";

// Kinetic হুক + কসমিক গ্লোব
const Globe: React.FC = () => {
  const frame = useCurrentFrame();
  const pIn = useSpring(0, theme.spring.smooth);
  const R = 220, C = 380;
  const meridians = Array.from({ length: 6 }).map((_, k) => {
    const a = frame / 70 + (k * Math.PI) / 6;
    return Math.abs(Math.cos(a)) * R;
  });
  const lats = [-60, -30, 0, 30, 60].map((d) => {
    const r = (d * Math.PI) / 180;
    return { y: C + R * Math.sin(r), rx: R * Math.cos(r) };
  });
  const orbit = (rx: number, ry: number, rot: number, speed: number, off: number, key: string) => {
    const th = frame * speed + off;
    return (
      <g key={key} transform={`rotate(${rot} ${C} ${C})`}>
        <ellipse cx={C} cy={C} rx={rx} ry={ry} fill="none" stroke={theme.colors.accent} strokeOpacity={0.35} strokeWidth={2} strokeDasharray="4 10" />
        <circle cx={C + rx * Math.cos(th)} cy={C + ry * Math.sin(th)} r={9} fill={theme.colors.accent} />
      </g>
    );
  };
  return (
    <svg width={760} height={760} viewBox="0 0 760 760" style={{
      opacity: pIn, transform: `scale(${interpolate(pIn, [0, 1], [0.7, 1])}) rotate(${interpolate(pIn, [0, 1], [-25, 0])}deg)` }}>
      <defs>
        <radialGradient id="g1-sphere" cx="38%" cy="32%" r="75%">
          <stop offset="0%" stopColor={theme.colors.bgAlt} />
          <stop offset="100%" stopColor={theme.colors.bgDeep} />
        </radialGradient>
        <radialGradient id="g1-halo" cx="50%" cy="50%" r="50%">
          <stop offset="55%" stopColor={theme.colors.hero} stopOpacity={0.5} />
          <stop offset="100%" stopColor={theme.colors.hero} stopOpacity={0} />
        </radialGradient>
      </defs>
      <circle cx={C} cy={C} r={R * 1.5 + Math.sin(frame / 30) * 8} fill="url(#g1-halo)" />
      <circle cx={C} cy={C} r={R} fill="url(#g1-sphere)" stroke={theme.colors.hero} strokeWidth={4} />
      {meridians.map((rx, i) => (
        <ellipse key={i} cx={C} cy={C} rx={Math.max(rx, 1)} ry={R} fill="none" stroke={theme.colors.hero} strokeOpacity={0.55} strokeWidth={2} />
      ))}
      {lats.map((l, i) => (
        <ellipse key={i} cx={C} cy={l.y} rx={l.rx} ry={Math.max(l.rx * 0.1, 1)} fill="none" stroke={theme.colors.hero} strokeOpacity={0.45} strokeWidth={2} />
      ))}
      {orbit(R * 1.5, R * 0.42, -22, 0.03, 0, "o1")}
      {orbit(R * 1.28, R * 0.34, 28, -0.022, 2, "o2")}
    </svg>
  );
};

export const S1Cosmos: React.FC<SceneProps> = ({ cues }) => {
  const cue = cues[0];
  return (
    <SceneShell glowX={74} glowY={50}>
      <Sfx name="thud" at={0} />
      <Sfx name="chime" at={24} />
      <div style={{ position: "absolute", left: 120, top: 0, bottom: 0, width: 980, display: "flex", flexDirection: "column",
        justifyContent: "center", alignItems: "center", gap: 18 }}>
        <KeywordPill text={cue.keyword ?? ""} delay={14} />
        <Arabic text={cue.arabic} size={theme.size.arabicHero} delay={0} maxWidth={980} />
        <Entrance delay={12} y={24}>
          <div style={{ width: 120, height: 4, borderRadius: 4, background: theme.colors.accent, opacity: 0.8 }} />
        </Entrance>
        <Bangla text={cue.bangla} size={theme.size.bnHero} delay={14} maxWidth={940} />
      </div>
      <div style={{ position: "absolute", left: 1040, top: 160 }}>
        <Globe />
      </div>
    </SceneShell>
  );
};
