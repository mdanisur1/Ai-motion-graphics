import React from "react";
import { Composition, staticFile } from "remotion";
import { Main } from "./Main";
import { Cue } from "./types";
import { FPS, HEIGHT, WIDTH } from "./config";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Main"
    component={Main}
    width={WIDTH}
    height={HEIGHT}
    fps={FPS}
    durationInFrames={FPS * 46}
    defaultProps={{ timeline: [] as Cue[] }}
    // দৈর্ঘ্য ও সময় — সবকিছু public/json/fatiha.json থেকে
    calculateMetadata={async () => {
      const res = await fetch(staticFile("json/fatiha.json"));
      const timeline = (await res.json()) as Cue[];
      const last = timeline[timeline.length - 1];
      return { durationInFrames: Math.ceil(last.end * FPS), props: { timeline } };
    }}
  />
);
