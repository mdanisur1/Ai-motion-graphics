export type Cue = {
  start: number;
  end: number;
  arabic: string;
  bangla: string;
  keyword?: string;
  bgTheme?: string;
  icon?: string;
};

export type SceneProps = { cues: Cue[]; from: number };
