import React from "react";
import { AbsoluteFill, Sequence, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "./theme";
import { LEAD, SCENE_GROUPS } from "./config";
import { Cue, SceneProps } from "./types";
import { BaseBg, Grade, Grain, Vignette, ProgressLine, Sfx, clamp01 } from "./components/common";
import { PreviewAudio } from "./components/PreviewAudio";
import { S1Cosmos } from "./scenes/S1Cosmos";
import { S2Mercy } from "./scenes/S2Mercy";
import { S3Justice } from "./scenes/S3Justice";
import { S4Hub } from "./scenes/S4Hub";
import { S5Path } from "./scenes/S5Path";
import { S6Split } from "./scenes/S6Split";
import { S7Light } from "./scenes/S7Light";

const SCENES: React.FC<SceneProps>[] = [S1Cosmos, S2Mercy, S3Justice, S4Hub, S5Path, S6Split, S7Light];

const Sweep: React.FC = () => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [0, 20], [0, 1], { ...clamp01, easing: theme.ease.inOut });
  const o = Math.sin(Math.PI * p);
  return (
    <AbsoluteFill style={{ pointerEvents: "none", overflow: "hidden" }}>
      <div style={{ position: "absolute", top: -100, bottom: -100, width: 560, left: interpolate(p, [0, 1], [-700, 2060]),
        transform: "skewX(-16deg)", filter: "blur(36px)", opacity: o * 0.8,
        background: `linear-gradient(90deg, transparent, ${theme.colors.accent}55, ${theme.colors.hero}44, transparent)` }} />
    </AbsoluteFill>
  );
};

export const Main: React.FC<{ timeline: Cue[] }> = ({ timeline }) => {
  const { fps, durationInFrames } = useVideoConfig();
  if (timeline.length === 0) return <AbsoluteFill style={{ background: theme.colors.bg }} />;

  const scenes = SCENE_GROUPS.map((group, i) => {
    const cues = group.map((k) => timeline[k]);
    const startF = Math.round(cues[0].start * fps);
    const from = Math.max(0, startF - LEAD);
    const endF = i === SCENE_GROUPS.length - 1 ? durationInFrames : Math.round(cues[cues.length - 1].end * fps);
    return { cues, from, dur: endF - from, startF };
  });

  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <BaseBg />
      {scenes.map((s, i) => {
        const Scene = SCENES[i];
        return (
          <Sequence key={i} from={s.from} durationInFrames={s.dur}>
            <Scene cues={s.cues} from={s.from} />
          </Sequence>
        );
      })}
      {scenes.slice(1).map((s, i) => (
        <React.Fragment key={`t${i}`}>
          <Sequence from={Math.max(0, s.startF - 9)} durationInFrames={20}><Sweep /></Sequence>
          <Sfx name="whoosh" at={s.startF - 12} rate={1 + (i % 3) * 0.04} />
        </React.Fragment>
      ))}
      <Grade />
      <Grain />
      <Vignette />
      <ProgressLine />
      <PreviewAudio />
    </AbsoluteFill>
  );
};
