// ---- প্রজেক্ট কনফিগ ----
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// ভিজ্যুয়াল কথার আগে ঢোকে (৪-৬ ফ্রেম)
export const LEAD = 5;

// JSON-এর কোন কোন cue নিয়ে একটি সিন (অর্থ অনুযায়ী; সীমা cue-র সীমায় মিলবে)
export const SCENE_GROUPS: number[][] = [[0], [1], [2], [3], [4], [5, 6], [7]];

// ভয়েসওভার প্রিভিউ: public/voiceover.mp3 থাকলে Studio-তে বাজবে
export const PREVIEW_AUDIO = {
  enabled: true, // এক ফ্ল্যাগে চালু/বন্ধ
  inRender: false, // ডিফল্টে রেন্ডারে বন্ধ
};
