import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { SceneProps } from "../types";
import { Arabic, Bangla, Entrance, KeywordPill, SceneShell, Sfx, useSpring } from "../components/common";

// Statement + দাঁড়িপাল্লা (বিচার)
const Scale: React.FC = () => {
  const frame = useCurrentFrame();
  const pIn = useSpring(0);
  const settle = useSpring(16, theme.spring.bouncy);
  const sway = Math.sin(frame / 26) * 1.2 * Math.min(1, Math.max(0, (frame - 50) / 30));
  const a = interpolate(settle, [0, 1], [15, 0]) + sway;
  const rad = (a * Math.PI) / 180;
  const CX = 380, PY = 120, L = 250, CH = 190;
  const lx = CX - L * Math.cos(rad), ly = PY - L * Math.sin(rad);
  const rx = CX + L * Math.cos(rad), ry = PY + L * Math.sin(rad);
  const pan = (x: number, y: number, key: string) => (
    <g key={key}>
      <line x1={x} y1={y} x2={x - 92} y2={y + CH} stroke={theme.colors.accent} strokeOpacity={0.7} strokeWidth={3} />
      <line x1={x} y1={y} x2={x + 92} y2={y + CH} stroke={theme.colors.accent} strokeOpacity={0.7} strokeWidth={3} />
      <path d={`M ${x - 106} ${y + CH} Q ${x} ${y + CH + 64} ${x + 106} ${y + CH} Z`} fill={theme.colors.accent} />
      <circle cx={x} cy={y} r={9} fill={theme.colors.accent} />
    </g>
  );
  return (
    <svg width={760} height={520} viewBox="0 0 760 520" style={{ opacity: pIn, transform: `translateY(${interpolate(pIn, [0, 1], [40, 0])}px) scale(${interpolate(pIn, [0, 1], [0.92, 1])})` }}>
      <defs>
        <linearGradient id="g3-pillar" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={theme.colors.textDim} stopOpacity={0.9} />
          <stop offset="100%" stopColor={theme.colors.muted} stopOpacity={0.6} />
        </linearGradient>
      </defs>
      <rect x={CX - 9} y={PY} width={18} height={350} rx={9} fill="url(#g3-pillar)" />
      <ellipse cx={CX} cy={472} rx={150} ry={22} fill={theme.colors.muted} fillOpacity={0.55} />
      <rect x={CX - 80} y={440} width={160} height={30} rx={14} fill="url(#g3-pillar)" />
      {pan(lx, ly, "l")}
      {pan(rx, ry, "r")}
      <line x1={lx} y1={ly} x2={rx} y2={ry} stroke={theme.colors.accent} strokeWidth={14} strokeLinecap="round" />
      <circle cx={CX} cy={PY} r={34 + Math.sin(frame / 18) * 2} fill={theme.colors.hero} style={{ filter: `drop-shadow(0 0 26px ${theme.colors.glow})` }} />
      <circle cx={CX} cy={PY} r={12} fill={theme.colors.text} />
    </svg>
  );
};

export const S3Justice: React.FC<SceneProps> = ({ cues }) => {
  const cue = cues[0];
  return (
    <SceneShell glowX={50} glowY={50} glowColor={theme.colors.accent}>
      <Sfx name="pop" at={4} rate={1.06} />
      <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 6, paddingBottom: 12 }}>
        <KeywordPill text={cue.keyword ?? ""} delay={12} />
        <Arabic text={cue.arabic} size={theme.size.arabicHero} delay={0} />
        <Scale />
        <Bangla text={cue.bangla} size={theme.size.bnHero} delay={14} />
      </div>
    </SceneShell>
  );
};
