import React from "react";
import { interpolate, random, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { SceneProps } from "../types";
import { Arabic, Bangla, Entrance, GlassCard, KeywordPill, SceneShell, Sfx, clamp01, useSpring } from "../components/common";

// Glass Cards + পানির ফোঁটা ও ঢেউ (রহমত)
const Drop: React.FC = () => {
  const frame = useCurrentFrame();
  const pIn = useSpring(0);
  const CX = 380, GY = 540, CYCLE = 62, FALL = 24;
  const f0 = frame - 6;
  const cycles = [0, 1, 2, 3].filter((n) => f0 - n * CYCLE >= 0);
  return (
    <svg width={760} height={860} viewBox="0 0 760 860" style={{ opacity: pIn }}>
      <defs>
        <radialGradient id="g2-water" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor={theme.colors.hero} stopOpacity={0.45} />
          <stop offset="100%" stopColor={theme.colors.hero} stopOpacity={0} />
        </radialGradient>
      </defs>
      {Array.from({ length: 16 }).map((_, i) => {
        const x = 40 + random(`rx${i}`) * 680;
        const sp = 6 + random(`rs${i}`) * 5;
        const y = (((random(`ry${i}`) * 900 + frame * sp) % 900) + 900) % 900 - 40;
        return <line key={i} x1={x} y1={y} x2={x - 6} y2={y + 46} stroke={theme.colors.textDim} strokeOpacity={0.14} strokeWidth={2} strokeLinecap="round" />;
      })}
      <ellipse cx={CX} cy={GY} rx={340} ry={110} fill="url(#g2-water)" />
      {cycles.map((n) =>
        [0, 1, 2].map((k) => {
          const age = f0 - n * CYCLE - FALL - k * 9;
          if (age < 0 || age > 80) return null;
          const u = interpolate(age, [0, 80], [0, 1], { ...clamp01, easing: theme.ease.out });
          const rx = 30 + u * 320;
          return <ellipse key={`${n}-${k}`} cx={CX} cy={GY} rx={rx} ry={rx * 0.28} fill="none" stroke={theme.colors.hero} strokeWidth={4} strokeOpacity={(1 - u) * 0.9} />;
        })
      )}
      {cycles.map((n) => {
        const t = f0 - n * CYCLE;
        if (t > FALL) return null;
        const y = interpolate(t, [0, FALL], [-80, GY - 40], { ...clamp01, easing: theme.ease.in });
        return (
          <path key={n} transform={`translate(${CX} ${y})`} fill={theme.colors.hero}
            style={{ filter: `drop-shadow(0 0 22px ${theme.colors.glow})` }}
            d="M0,-48 C24,-14 36,6 36,24 A36,36 0 1 1 -36,24 C-36,6 -24,-14 0,-48 Z" />
        );
      })}
    </svg>
  );
};

export const S2Mercy: React.FC<SceneProps> = ({ cues }) => {
  const cue = cues[0];
  return (
    <SceneShell glowX={26} glowY={55}>
      <Sfx name="pop" at={4} />
      <div style={{ position: "absolute", left: 90, top: 150 }}><Drop /></div>
      <div style={{ position: "absolute", left: 930, top: 0, bottom: 0, width: 900, display: "flex", alignItems: "center" }}>
        <Entrance delay={0} y={50} scaleFrom={0.92} style={{ width: "100%" }}>
          <GlassCard strong style={{ padding: "54px 56px 60px", display: "flex", flexDirection: "column", alignItems: "center", gap: 14 }}>
            <KeywordPill text={cue.keyword ?? ""} delay={8} />
            <Arabic text={cue.arabic} size={theme.size.arabicHero} delay={4} maxWidth={780} />
            <Entrance delay={16} y={10}>
              <div style={{ width: 760, height: 2, background: theme.colors.glassBorder }} />
            </Entrance>
            <Bangla text={cue.bangla} size={theme.size.bnHero} delay={18} maxWidth={780} />
          </GlassCard>
        </Entrance>
      </div>
    </SceneShell>
  );
};
