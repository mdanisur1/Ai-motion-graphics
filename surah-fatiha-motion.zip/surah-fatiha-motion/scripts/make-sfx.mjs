// নরম, ছোট UI সাউন্ড কিট — কোডে সিন্থেসাইজ (কোনো ডাউনলোড লাগে না)।
// চালান: node scripts/make-sfx.mjs   → public/sfx/*.wav (16-bit, 44.1kHz, mono)
import { writeFileSync, mkdirSync } from "node:fs";

const SR = 44100;
const OUT = new URL("../public/sfx/", import.meta.url).pathname;
mkdirSync(OUT, { recursive: true });

// --- সহায়ক ---
const buf = (sec) => new Float32Array(Math.floor(sec * SR));
const lowpass = (x, a) => { let y = 0; for (let i = 0; i < x.length; i++) { y += a * (x[i] - y); x[i] = y; } return x; };
const highpass = (x, a) => { let y = 0; for (let i = 0; i < x.length; i++) { y += a * (x[i] - y); x[i] = x[i] - y; } return x; };
const attack = (t, s) => (t >= s ? 1 : Math.sin((t / s) * Math.PI / 2) ** 2); // নরম attack
let seed = 12345;
const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296 * 2 - 1; };

// ছোট reverb (তিনটি দ্রুত delay tap)
const smallReverb = (x, mix = 0.16) => {
  const taps = [[0.029, 0.22], [0.037, 0.17], [0.053, 0.12]];
  const y = new Float32Array(x.length);
  for (let i = 0; i < x.length; i++) {
    let v = x[i];
    for (const [d, g] of taps) { const j = i - Math.floor(d * SR); if (j >= 0) v += x[j] * g * mix * 4; }
    y[i] = v;
  }
  return y;
};
const fadeEnd = (x, sec = 0.025) => { const n = Math.floor(sec * SR); for (let i = 0; i < n; i++) x[x.length - 1 - i] *= i / n; return x; };

// --- সাউন্ড ---
const pop = () => {                 // দ্রুত নিচে নামা pitch সহ sine + ছোট envelope
  const x = buf(0.26); let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR; const f = 190 + 640 * Math.exp(-t / 0.028);
    ph += 2 * Math.PI * f / SR;
    x[i] = Math.sin(ph) * attack(t, 0.004) * Math.exp(-t / 0.055);
  }
  return smallReverb(lowpass(x, 0.3), 0.12);
};
const click = () => {               // high-pass করা ছোট noise burst
  const x = buf(0.12);
  for (let i = 0; i < x.length; i++) { const t = i / SR; x[i] = (rnd() * 0.8 + Math.sin(2 * Math.PI * 1900 * t) * 0.35) * attack(t, 0.0012) * Math.exp(-t / 0.011); }
  return smallReverb(lowpass(highpass(x, 0.12), 0.42), 0.1);
};
const whoosh = () => {              // band-pass noise sweep + fade in/out
  const dur = 0.72; const x = buf(dur);
  let lp = 0, bp = 0; const q = 0.9;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR, u = t / dur;
    const fc = 380 * Math.pow(7.5, u);
    const f = 2 * Math.sin(Math.PI * fc / SR);
    const n = rnd();
    const hp = n - lp - q * bp; bp += f * hp; lp += f * bp;
    x[i] = bp * Math.sin(Math.PI * Math.pow(u, 0.75)) ** 2;
  }
  return smallReverb(lowpass(x, 0.38), 0.1);
};
const chime = () => {               // নরম ওভারটোনসহ ছোট decay
  const x = buf(0.58); const f0 = 880;
  const parts = [[1, 1, 0.2], [2.0, 0.32, 0.13], [3.01, 0.14, 0.08]];
  for (let i = 0; i < x.length; i++) {
    const t = i / SR; let v = 0;
    for (const [m, g, d] of parts) v += Math.sin(2 * Math.PI * f0 * m * t) * g * Math.exp(-t / d);
    x[i] = v * attack(t, 0.006);
  }
  return smallReverb(lowpass(x, 0.4), 0.18);
};
const thud = () => {                // খুব হালকা সফট থাড
  const x = buf(0.42); let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR; const f = 46 + 44 * Math.exp(-t / 0.05);
    ph += 2 * Math.PI * f / SR;
    x[i] = Math.sin(ph) * attack(t, 0.008) * Math.exp(-t / 0.1);
  }
  return lowpass(x, 0.14);
};

// --- নর্মালাইজ + WAV লেখা + যাচাই ---
const TARGET_PEAK = 0.85, TARGET_RMS_DB = -19;
const toWav = (x) => {
  const n = x.length, b = Buffer.alloc(44 + n * 2);
  b.write("RIFF", 0); b.writeUInt32LE(36 + n * 2, 4); b.write("WAVE", 8); b.write("fmt ", 12);
  b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22); b.writeUInt32LE(SR, 24);
  b.writeUInt32LE(SR * 2, 28); b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34); b.write("data", 36); b.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) b.writeInt16LE(Math.round(Math.max(-1, Math.min(1, x[i])) * 32767), 44 + i * 2);
  return b;
};
const kit = { pop, click, whoosh, chime, thud };
console.log("name     dur(s)  peak   rms(dB)  clip");
for (const [name, fn] of Object.entries(kit)) {
  const x = fadeEnd(fn());
  let peak = 0, sum = 0;
  for (const v of x) { peak = Math.max(peak, Math.abs(v)); sum += v * v; }
  const rms = Math.sqrt(sum / x.length);
  const gain = Math.min(TARGET_PEAK / peak, Math.pow(10, TARGET_RMS_DB / 20) / rms);
  for (let i = 0; i < x.length; i++) x[i] *= gain;
  let p2 = 0, s2 = 0, clip = 0;
  for (const v of x) { p2 = Math.max(p2, Math.abs(v)); s2 += v * v; if (Math.abs(v) >= 0.999) clip++; }
  writeFileSync(OUT + name + ".wav", toWav(x));
  console.log(`${name.padEnd(8)} ${(x.length / SR).toFixed(2)}    ${p2.toFixed(2)}   ${(20 * Math.log10(Math.sqrt(s2 / x.length))).toFixed(1)}    ${clip === 0 ? "ok" : "CLIP"}`);
}
