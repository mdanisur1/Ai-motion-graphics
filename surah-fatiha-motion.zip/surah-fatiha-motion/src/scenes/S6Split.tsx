import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { SceneProps, Cue } from "../types";
import { Arabic, Bangla, Entrance, GlassCard, KeywordPill, SceneShell, Sfx, clamp01, useCueAt, useSpring } from "../components/common";

// Before/After Split: নিআমতের পথ বনাম গজবের পথ
const Blessing: React.FC<{ delay: number }> = ({ delay }) => {
  const frame = useCurrentFrame();
  const rays = 14;
  return (
    <svg width={260} height={220} viewBox="-130 -110 260 220">
      {Array.from({ length: rays }).map((_, i) => {
        const p = interpolate(frame - delay - i * 1.4, [0, 16], [0, 1], { ...clamp01, easing: theme.ease.out });
        return <rect key={i} x={-4} y={-18 - 78 * p} width={8} height={36 + 40 * p} rx={4} fill={theme.colors.accent} opacity={0.9}
          transform={`rotate(${(360 / rays) * i + frame * 0.4}) translate(0 -32)`} />;
      })}
      <circle r={40 + Math.sin(frame / 16) * 3} fill={theme.colors.hero} style={{ filter: `drop-shadow(0 0 30px ${theme.colors.glow})` }} />
    </svg>
  );
};

const Warning: React.FC<{ delay: number }> = ({ delay }) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame - delay, [0, 22], [0, 1], { ...clamp01, easing: theme.ease.out });
  return (
    <svg width={260} height={220} viewBox="-130 -110 260 220">
      <path d="M0,-95 L78,-62 L78,12 C78,56 40,86 0,100 C-40,86 -78,56 -78,12 L-78,-62 Z" fill="none" stroke={theme.colors.muted} strokeWidth={8}
        strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} />
      <rect x={-7} y={-42} width={14} height={62} rx={7} fill={theme.colors.muted} opacity={p} />
      <circle cx={0} cy={44} r={9} fill={theme.colors.muted} opacity={p} />
    </svg>
  );
};

const Badge: React.FC<{ kind: "check" | "cross"; delay: number }> = ({ kind, delay }) => {
  const p = useSpring(delay, theme.spring.bouncy);
  const good = kind === "check";
  return (
    <div style={{ position: "absolute", top: 30, right: 34, width: 76, height: 76, borderRadius: "50%", transform: `scale(${p})`, opacity: Math.min(1, p),
      background: good ? theme.colors.accent : theme.colors.glassStrong, border: good ? "none" : `3px solid ${theme.colors.muted}`,
      display: "flex", alignItems: "center", justifyContent: "center" }}>
      <svg width={40} height={40} viewBox="0 0 40 40">
        {good
          ? <path d="M8 21 L17 29 L33 11" fill="none" stroke={theme.colors.bgDeep} strokeWidth={6} strokeLinecap="round" strokeLinejoin="round" />
          : <path d="M10 10 L30 30 M30 10 L10 30" fill="none" stroke={theme.colors.muted} strokeWidth={6} strokeLinecap="round" />}
      </svg>
    </div>
  );
};

const Panel: React.FC<{ cue: Cue; at: number; left: number; side: "good" | "bad"; dimTo?: number }> = ({ cue, at, left, side, dimTo = 1 }) => {
  const frame = useCurrentFrame();
  const good = side === "good";
  const dim = interpolate(frame, [at, at + 30], [1, dimTo], { ...clamp01, easing: theme.ease.out });
  return (
    <div style={{ position: "absolute", left, top: 120, width: 840, height: 820, opacity: dim }}>
      <Entrance delay={at} y={50} scaleFrom={0.93} style={{ width: "100%", height: "100%" }}>
        <GlassCard strong={good} style={{ width: "100%", height: "100%", boxSizing: "border-box", padding: "38px 50px", position: "relative",
          display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 6,
          borderColor: good ? `${theme.colors.accent}88` : theme.colors.glassBorder }}>
          <Badge kind={good ? "check" : "cross"} delay={at + 22} />
          <div style={{ marginBottom: 22 }}>{good ? <Blessing delay={at + 6} /> : <Warning delay={at + 6} />}</div>
          <KeywordPill text={cue.keyword ?? ""} delay={at + 12} muted={!good} />
          <Arabic text={cue.arabic} size={78} delay={at + 4} maxWidth={740} color={good ? theme.colors.text : theme.colors.textDim} />
          <Bangla text={cue.bangla} size={44} delay={at + 14} maxWidth={740} color={good ? theme.colors.textDim : theme.colors.muted} />
        </GlassCard>
      </Entrance>
    </div>
  );
};

export const S6Split: React.FC<SceneProps> = ({ cues, from }) => {
  const at = useCueAt(cues, from);
  return (
    <SceneShell glowX={30} glowY={50}>
      <Sfx name="pop" at={at[0] + 4} />
      <Sfx name="click" at={at[0] + 24} />
      <Sfx name="pop" at={at[1] + 4} rate={0.92} />
      <Sfx name="click" at={at[1] + 24} rate={0.9} />
      <Panel cue={cues[0]} at={at[0]} left={90} side="good" dimTo={0.72} />
      <Panel cue={cues[1]} at={at[1]} left={990} side="bad" />
    </SceneShell>
  );
};
