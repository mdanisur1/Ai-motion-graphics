import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { SceneProps } from "../types";
import { Arabic, Bangla, Entrance, GlassCard, SceneShell, Sfx, clamp01, useCueAt, useCueLen, useSpring } from "../components/common";

// Hub and Spoke: "আপনারই" কেন্দ্র, দুই শাখা — ইবাদত ও সাহায্য
const HUB = { x: 470, y: 545 };
const ITEMS = [
  { ar: "نَعْبُدُ", bn: "ইবাদত", cardY: 405 },
  { ar: "نَسْتَعِينُ", bn: "সাহায্য", cardY: 685 },
];
const CARD_X = 1010;

const bez = (u: number, y1: number) => {
  const p0 = [HUB.x + 120, HUB.y], p1 = [800, HUB.y], p2 = [800, y1], p3 = [CARD_X, y1];
  const m = 1 - u;
  const f = (i: number) => m ** 3 * p0[i] + 3 * m * m * u * p1[i] + 3 * m * u * u * p2[i] + u ** 3 * p3[i];
  return { x: f(0), y: f(1) };
};

export const S4Hub: React.FC<SceneProps> = ({ cues, from }) => {
  const cue = cues[0];
  const frame = useCurrentFrame();
  const [len] = useCueLen(cues);
  useCueAt(cues, from);
  // একাধিক আইটেম: cue-র সময়ে সমান ব্যবধানে
  const itemAt = ITEMS.map((_, i) => Math.round((i * len) / ITEMS.length));
  const hubP = useSpring(6, theme.spring.bouncy);
  return (
    <SceneShell glowX={25} glowY={50}>
      <Sfx name="pop" at={6} />
      <Sfx name="pop" at={itemAt[0] + 14} rate={1.08} />
      <Sfx name="pop" at={itemAt[1] + 14} rate={1.14} />
      <div style={{ position: "absolute", left: 0, right: 0, top: 70, display: "flex", justifyContent: "center" }}>
        <Arabic text={cue.arabic} size={theme.size.arabicMid} delay={0} />
      </div>

      <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{ position: "absolute", inset: 0 }}>
        <defs>
          <radialGradient id="g4-orb" cx="40%" cy="35%" r="70%">
            <stop offset="0%" stopColor="#7C9BFF" />
            <stop offset="100%" stopColor={theme.colors.hero} />
          </radialGradient>
        </defs>
        {/* রিং */}
        <g opacity={hubP}>
          <circle cx={HUB.x} cy={HUB.y} r={178} fill="none" stroke={theme.colors.accent} strokeOpacity={0.4} strokeWidth={2} strokeDasharray="3 12"
            transform={`rotate(${frame * 0.5} ${HUB.x} ${HUB.y})`} />
          <circle cx={HUB.x} cy={HUB.y} r={226} fill="none" stroke={theme.colors.glassBorder} strokeWidth={2} strokeDasharray="2 16"
            transform={`rotate(${-frame * 0.35} ${HUB.x} ${HUB.y})`} />
        </g>
        {ITEMS.map((it, i) => {
          const d = Math.max(0, itemAt[i] - 4);
          const draw = interpolate(frame, [d, d + 22], [0, 1], { ...clamp01, easing: theme.ease.out });
          const path = `M ${HUB.x + 120} ${HUB.y} C 800 ${HUB.y} 800 ${it.cardY} ${CARD_X} ${it.cardY}`;
          const u = (((frame - d - 22) * 0.012) % 1 + 1) % 1;
          const dot = bez(u, it.cardY);
          return (
            <g key={i}>
              <path d={path} pathLength={1} fill="none" stroke={theme.colors.accent} strokeWidth={4} strokeLinecap="round"
                strokeDasharray={1} strokeDashoffset={1 - draw} strokeOpacity={0.85} />
              {frame > d + 22 && <circle cx={dot.x} cy={dot.y} r={8} fill={theme.colors.accent} />}
            </g>
          );
        })}
        {/* কেন্দ্রের orb (হিরো) */}
        <g transform={`translate(${HUB.x} ${HUB.y}) scale(${hubP * (1 + Math.sin(frame / 24) * 0.02)})`}>
          <circle r={150} fill="url(#g4-orb)" style={{ filter: `drop-shadow(0 0 50px ${theme.colors.glow})` }} />
        </g>
      </svg>
      <div style={{ position: "absolute", left: HUB.x - 150, top: HUB.y - 150, width: 300, height: 300, display: "flex", alignItems: "center", justifyContent: "center",
        opacity: hubP, transform: `scale(${hubP})` }}>
        <span style={{ fontFamily: theme.fonts.ar, fontWeight: 700, fontSize: 84, color: theme.colors.text, lineHeight: 1.8 }}>إِيَّاكَ</span>
      </div>

      {ITEMS.map((it, i) => (
        <div key={i} style={{ position: "absolute", left: CARD_X, top: it.cardY - 85, width: 640, height: 170 }}>
          <Entrance delay={Math.max(0, itemAt[i] + 8)} y={30} config={theme.spring.bouncy} style={{ width: "100%", height: "100%" }}>
            <GlassCard strong style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 52px", boxSizing: "border-box" }}>
              <span style={{ fontFamily: theme.fonts.bn, fontWeight: 700, fontSize: 68, color: theme.colors.text, lineHeight: 1.4 }}>{it.bn}</span>
              <span style={{ fontFamily: theme.fonts.ar, fontWeight: 700, fontSize: 68, color: theme.colors.accent, lineHeight: 1.8 }}>{it.ar}</span>
            </GlassCard>
          </Entrance>
        </div>
      ))}

      <div style={{ position: "absolute", left: 0, right: 0, bottom: 74, display: "flex", justifyContent: "center" }}>
        <Bangla text={cue.bangla} size={theme.size.bnMid} delay={16} maxWidth={1700} />
      </div>
    </SceneShell>
  );
};
