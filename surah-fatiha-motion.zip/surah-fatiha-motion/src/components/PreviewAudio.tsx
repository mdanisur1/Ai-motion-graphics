import React, { useEffect, useState } from "react";
import { Audio, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";
import { PREVIEW_AUDIO } from "../config";

/** public/voiceover.mp3 থাকলে বাজবে, না থাকলে নীরবে বাদ। রেন্ডারে ডিফল্টে বন্ধ। */
export const PreviewAudio: React.FC = () => {
  const [ok, setOk] = useState(false);
  const [handle] = useState(() => delayRender("voiceover check"));
  useEffect(() => {
    let alive = true;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") ?? "";
        if (alive) setOk(r.ok && !type.includes("text/html"));
      })
      .catch(() => undefined)
      .finally(() => continueRender(handle));
    return () => { alive = false; };
  }, [handle]);

  const rendering = getRemotionEnvironment().isRendering;
  if (!PREVIEW_AUDIO.enabled || (rendering && !PREVIEW_AUDIO.inRender) || !ok) return null;
  return <Audio src={staticFile("voiceover.mp3")} volume={1} />;
};
