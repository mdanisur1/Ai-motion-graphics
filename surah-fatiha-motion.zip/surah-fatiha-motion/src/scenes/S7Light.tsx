import React from "react";
import { interpolate, random, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { SceneProps } from "../types";
import { Arabic, Bangla, Entrance, GlassCard, KeywordPill, SceneShell, Sfx, clamp01, toBn, useCueLen, useSpring } from "../components/common";

// কুয়াশা কাটে, আলো ফোটে → Recap Grid → শিরোনাম
const Beacon: React.FC<{ dim: number }> = ({ dim }) => {
  const frame = useCurrentFrame();
  const open = interpolate(frame, [0, 70], [0, 1], { ...clamp01, easing: theme.ease.out }) * (1 - 0.6 * dim);
  const rays = 18;
  return (
    <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{ position: "absolute", inset: 0 }}>
      <defs>
        <radialGradient id="g7-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor={theme.colors.accent} stopOpacity={0.55} />
          <stop offset="100%" stopColor={theme.colors.accent} stopOpacity={0} />
        </radialGradient>
        <radialGradient id="g7-core" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor={theme.colors.hero} stopOpacity={0.9} />
          <stop offset="100%" stopColor={theme.colors.hero} stopOpacity={0} />
        </radialGradient>
      </defs>
      <g transform={`translate(960 300)`} opacity={open}>
        <circle r={520 + Math.sin(frame / 30) * 14} fill="url(#g7-glow)" />
        {Array.from({ length: rays }).map((_, i) => (
          <polygon key={i} points="0,0 -14,-760 14,-760" fill={theme.colors.accent} opacity={0.06 + 0.04 * Math.sin(frame / 25 + i)}
            style={{ filter: "blur(5px)" }} transform={`rotate(${(360 / rays) * i + frame * 0.15})`} />
        ))}
        <circle r={110} fill="url(#g7-core)" />
      </g>
    </svg>
  );
};

const Fog: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <>
      {Array.from({ length: 6 }).map((_, i) => {
        const clear = interpolate(frame, [i * 6, 60 + i * 12], [1, 0], { ...clamp01, easing: theme.ease.inOut });
        const dir = i % 2 === 0 ? -1 : 1;
        const x = 100 + random(`fx${i}`) * 1100 + dir * (1 - clear) * 520;
        const y = 120 + random(`fy${i}`) * 700;
        return <div key={i} style={{ position: "absolute", left: x, top: y, width: 760, height: 280, borderRadius: "50%", filter: "blur(70px)",
          background: theme.colors.textDim, opacity: 0.2 * clear }} />;
      })}
    </>
  );
};

export const S7Light: React.FC<SceneProps> = ({ cues, from }) => {
  const cue = cues[0];
  const { durationInFrames } = useVideoConfig();
  const [len] = useCueLen(cues);
  const frame = useCurrentFrame();
  void from;
  const recapAt = Math.round(len * 0.42);
  const shift = useSpring(recapAt, theme.spring.smooth);
  const bnFade = interpolate(frame, [recapAt - 6, recapAt + 10], [1, 0], { ...clamp01, easing: theme.ease.in });
  const labels = ["সৃষ্টিকুলের রব", "পরম করুণাময়", "বিচার দিবসের মালিক", "ইবাদত ও সাহায্য", "সরল পথ", "নিআমতপ্রাপ্তদের পথ", "গজবপ্রাপ্তদের নয়", cue.keyword ?? ""];
  const titleAt = recapAt + labels.length * 4 + 20;
  void durationInFrames;
  return (
    <SceneShell glowX={50} glowY={30} glowColor={theme.colors.accent}>
      <Sfx name="chime" at={2} />
      <Sfx name="pop" at={recapAt - 2} rate={0.94} />
      <Sfx name="chime" at={titleAt} rate={1.12} />
      <Beacon dim={shift} />
      <Fog />
      {/* আরবি: কেন্দ্র থেকে উপরে সরে যায় */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 0, display: "flex", justifyContent: "center",
        transform: `translateY(${interpolate(shift, [0, 1], [250, 70])}px) scale(${interpolate(shift, [0, 1], [1.12, 0.62])})`, transformOrigin: "50% 0%" }}>
        <Arabic text={cue.arabic} size={theme.size.arabicHero} delay={0} />
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 520, display: "flex", flexDirection: "column", alignItems: "center", gap: 16,
        opacity: bnFade, transform: `translateY(${interpolate(bnFade, [0, 1], [-20, 0])}px)` }}>
        <KeywordPill text={cue.keyword ?? ""} delay={10} />
        <Bangla text={cue.bangla} size={theme.size.bnHero} delay={12} maxWidth={1300} />
      </div>
      {/* Recap Grid */}
      <div style={{ position: "absolute", left: 95, top: 350, width: 1730, display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 28 }}>
        {labels.map((t, i) => (
          <Entrance key={i} delay={recapAt + i * 4} y={30} scaleFrom={0.92}>
            <GlassCard strong style={{ height: 150, borderRadius: theme.radius.chip, display: "flex", alignItems: "center", gap: 20, padding: "0 28px", boxSizing: "border-box" }}>
              <div style={{ flex: "0 0 62px", width: 62, height: 62, borderRadius: "50%", border: `2.5px solid ${theme.colors.accent}`, color: theme.colors.accent,
                display: "flex", alignItems: "center", justifyContent: "center", fontFamily: theme.fonts.bn, fontWeight: 700, fontSize: 34, lineHeight: 1 }}>
                {toBn(i + 1)}
              </div>
              <span style={{ fontFamily: theme.fonts.bn, fontWeight: 700, fontSize: 36, color: theme.colors.text, lineHeight: 1.4 }}>{t}</span>
            </GlassCard>
          </Entrance>
        ))}
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, top: 810, display: "flex", justifyContent: "center" }}>
        <Entrance delay={titleAt} y={30} config={theme.spring.bouncy}>
          <div style={{ fontFamily: theme.fonts.bn, fontWeight: 700, fontSize: 96, lineHeight: 1.5, color: theme.colors.accent,
            textShadow: `0 0 50px ${theme.colors.accentGlow}` }}>সূরা আল-ফাতিহা</div>
        </Entrance>
      </div>
    </SceneShell>
  );
};
