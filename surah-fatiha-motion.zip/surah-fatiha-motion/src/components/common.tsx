import React from "react";
import {
  AbsoluteFill,
  Audio,
  Sequence,
  interpolate,
  random,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { theme, SfxName } from "../theme";
import { LEAD } from "../config";
import { Cue } from "../types";

// ---------- সহায়ক ----------
const BN_DIGITS = ["০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"];
export const toBn = (n: number) =>
  String(n).split("").map((d) => BN_DIGITS[Number(d)] ?? d).join("");

export const clamp01 = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

type SpringCfg = { damping: number; stiffness: number; mass: number };

export const useSpring = (delay = 0, config: SpringCfg = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config });
};

/** সিনের ভেতরে প্রতিটি cue কোন ফ্রেমে ঢুকবে (cue-র LEAD ফ্রেম আগে) */
export const useCueAt = (cues: Cue[], from: number) => {
  const { fps } = useVideoConfig();
  return cues.map((c) => Math.max(0, Math.round(c.start * fps) - from - LEAD));
};
export const useCueLen = (cues: Cue[]) => {
  const { fps } = useVideoConfig();
  return cues.map((c) => Math.round((c.end - c.start) * fps));
};

// ---------- ব্যাকগ্রাউন্ড (গ্লোবাল) ----------
export const BaseBg: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 60;
  const d2 = Math.cos(frame / 70) * 50;
  return (
    <AbsoluteFill style={{ background: `linear-gradient(180deg, ${theme.colors.bg}, ${theme.colors.bgDeep})` }}>
      <div style={{ position: "absolute", width: 1300, height: 1300, borderRadius: "50%", top: -560, left: -320 + d1,
        filter: "blur(60px)", background: `radial-gradient(circle, ${theme.colors.hero}2E, transparent 62%)` }} />
      <div style={{ position: "absolute", width: 1000, height: 1000, borderRadius: "50%", bottom: -480, right: -260 - d2,
        filter: "blur(70px)", background: `radial-gradient(circle, ${theme.colors.accent}1A, transparent 65%)` }} />
      <Particles />
    </AbsoluteFill>
  );
};

export const Particles: React.FC<{ count?: number }> = ({ count = 38 }) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill>
      {Array.from({ length: count }).map((_, i) => {
        const x = random(`px${i}`) * 1920;
        const speed = 0.18 + random(`ps${i}`) * 0.4;
        const size = 2 + random(`pz${i}`) * 4;
        const y = ((random(`py${i}`) * 1200 - frame * speed * 3) % 1200 + 1200) % 1200 - 60;
        const tw = 0.25 + 0.35 * Math.abs(Math.sin(frame / (30 + random(`pt${i}`) * 40) + i));
        return (
          <div key={i} style={{ position: "absolute", left: x + Math.sin(frame / 50 + i) * 12, top: y, width: size, height: size,
            borderRadius: "50%", background: theme.colors.accent, opacity: tw * 0.55 }} />
        );
      })}
    </AbsoluteFill>
  );
};

// ---------- গ্রেড, গ্রেন, ভিনিয়েট (গ্লোবাল, সবার উপরে) ----------
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.hero, mixBlendMode: "soft-light", opacity: 0.2 }} />
    <AbsoluteFill style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 28%, transparent 72%, rgba(0,0,0,0.22))" }} />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px",
      backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, opacity: 0.06, mixBlendMode: "overlay" }} />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.32) 100%)" }} />
);

export const ProgressLine: React.FC = () => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const p = interpolate(frame, [0, durationInFrames], [0, 1], { ...clamp01, easing: theme.ease.inOut });
  return (
    <div style={{ position: "absolute", left: 0, bottom: 0, height: 6, width: `${p * 100}%`,
      background: theme.colors.accent, opacity: 0.55, borderRadius: "0 6px 6px 0" }} />
  );
};

// ---------- সিনের খোলস: সিন-নির্দিষ্ট আলো + এক্সিট ----------
export const SceneShell: React.FC<{
  children: React.ReactNode;
  glowX?: number; glowY?: number; glowColor?: string;
}> = ({ children, glowX = 50, glowY = 50, glowColor = theme.colors.hero }) => {
  const frame = useCurrentFrame();
  const { durationInFrames, fps } = useVideoConfig();
  const exitLen = Math.round(fps * 0.33);
  const exit = interpolate(frame, [durationInFrames - exitLen, durationInFrames - 2], [0, 1], { ...clamp01, easing: theme.ease.in });
  const glowIn = interpolate(frame, [0, 24], [0, 1], { ...clamp01, easing: theme.ease.out });
  const breathe = 1 + Math.sin(frame / 40) * 0.05;
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: `${glowX}%`, top: `${glowY}%`, width: 1100, height: 1100,
        marginLeft: -550, marginTop: -550, borderRadius: "50%", filter: "blur(40px)",
        background: `radial-gradient(circle, ${glowColor}30, transparent 62%)`,
        opacity: glowIn * (1 - exit), transform: `scale(${breathe})` }} />
      <AbsoluteFill style={{ opacity: 1 - exit, transform: `translateY(${-30 * exit}px) scale(${1 + 0.015 * exit})` }}>
        {children}
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

// ---------- এন্ট্রান্স ----------
export const Entrance: React.FC<{
  delay?: number; y?: number; scaleFrom?: number; style?: React.CSSProperties; children: React.ReactNode;
  config?: SpringCfg;
}> = ({ delay = 0, y = 40, scaleFrom = 0.94, style, children, config = theme.spring.smooth }) => {
  const p = useSpring(delay, config);
  return (
    <div style={{ opacity: p, transform: `translateY(${interpolate(p, [0, 1], [y, 0])}px) scale(${interpolate(p, [0, 1], [scaleFrom, 1])})`, ...style }}>
      {children}
    </div>
  );
};

// ---------- শব্দ ধরে টেক্সট (বাংলা/আরবি: কখনো অক্ষর ভাঙে না) ----------
export const WordReveal: React.FC<{
  text: string; size: number; weight?: number; color?: string; family: string;
  delay?: number; per?: number; rtl?: boolean; align?: "center" | "start";
  accent?: number[]; accentColor?: string; hlDelay?: number;
  lineHeight?: number; maxWidth?: number;
}> = ({ text, size, weight = 700, color = theme.colors.text, family, delay = 0, per = 4, rtl = false,
  align = "center", accent = [], accentColor = theme.colors.accent, hlDelay, lineHeight = 1.5, maxWidth }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const words = text.split(" ").filter(Boolean);
  const hlStart = hlDelay ?? delay + words.length * per + 6;
  return (
    <div style={{ display: "flex", flexWrap: "wrap", direction: rtl ? "rtl" : "ltr",
      justifyContent: align === "center" ? "center" : "flex-start", columnGap: Math.round(size * 0.3), rowGap: 0,
      fontFamily: family, fontSize: size, fontWeight: weight, lineHeight, letterSpacing: 0, color, maxWidth }}>
      {words.map((w, i) => {
        const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring.snappy });
        const isA = accent.includes(i);
        const hl = isA ? spring({ frame: frame - hlStart - accent.indexOf(i) * 4, fps, config: theme.spring.smooth }) : 0;
        return (
          <span key={i} style={{ display: "inline-block", position: "relative", opacity: p, color: isA ? accentColor : color,
            transform: `translateY(${interpolate(p, [0, 1], [34, 0])}px) scale(${interpolate(p, [0, 1], [0.92, 1])})` }}>
            {w}
            {isA && (
              <span style={{ position: "absolute", left: 0, right: 0, bottom: -size * 0.02, height: Math.max(4, Math.round(size * 0.07)),
                borderRadius: 99, background: accentColor, opacity: 0.85 * Math.min(1, hl), transform: `scaleX(${Math.min(1, Math.max(0, hl))})`,
                transformOrigin: rtl ? "100% 50%" : "0% 50%" }} />
            )}
          </span>
        );
      })}
    </div>
  );
};

export const Arabic: React.FC<{ text: string; size?: number; delay?: number; maxWidth?: number; color?: string; per?: number }> = ({
  text, size = theme.size.arabicHero, delay = 0, maxWidth, color, per = 5,
}) => (
  <WordReveal text={text} size={size} family={theme.fonts.ar} weight={700} rtl delay={delay} per={per} lineHeight={1.75} maxWidth={maxWidth} color={color} />
);

export const Bangla: React.FC<{ text: string; size?: number; delay?: number; maxWidth?: number; color?: string; accent?: number[]; hlDelay?: number; per?: number }> = ({
  text, size = theme.size.bnHero, delay = 0, maxWidth, color = theme.colors.textDim, accent, hlDelay, per = 4,
}) => (
  <WordReveal text={text} size={size} family={theme.fonts.bn} weight={500} delay={delay} per={per} lineHeight={1.55} maxWidth={maxWidth} color={color} accent={accent} hlDelay={hlDelay} />
);

export const KeywordPill: React.FC<{ text: string; delay?: number; muted?: boolean; size?: number }> = ({ text, delay = 0, muted = false, size = theme.size.pill }) => {
  const c = muted ? theme.colors.muted : theme.colors.accent;
  return (
    <Entrance delay={delay} y={20} scaleFrom={0.9} config={theme.spring.bouncy}>
      <div style={{ display: "inline-block", padding: "10px 30px 14px", borderRadius: theme.radius.pill, border: `2px solid ${c}`,
        color: c, fontFamily: theme.fonts.bn, fontWeight: 700, fontSize: size, lineHeight: 1.4, background: theme.colors.glass }}>
        {text}
      </div>
    </Entrance>
  );
};

export const GlassCard: React.FC<{ style?: React.CSSProperties; children: React.ReactNode; strong?: boolean }> = ({ style, children, strong }) => (
  <div style={{ borderRadius: theme.radius.card, background: strong ? theme.colors.glassStrong : theme.colors.glass,
    border: `1.5px solid ${theme.colors.glassBorder}`, boxShadow: theme.shadow.card, backdropFilter: "blur(14px)", ...style }}>
    {children}
  </div>
);

// ---------- সাউন্ড ----------
export const Sfx: React.FC<{ name: SfxName; at: number; rate?: number }> = ({ name, at, rate = 1 }) => {
  const { fps } = useVideoConfig();
  const cfg = theme.sfx[name];
  return (
    <Sequence from={Math.max(0, Math.round(at))} durationInFrames={Math.ceil((cfg.seconds / rate) * fps) + 2} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={cfg.volume} playbackRate={rate} />
    </Sequence>
  );
};
