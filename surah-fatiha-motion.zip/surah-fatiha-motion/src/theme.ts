// theme.ts — রং, ইজিং, spring, ফন্ট, সাউন্ড লেভেল: সবকিছুর একমাত্র উৎস।
import { Easing } from "remotion";
import { loadFont as loadBengali } from "@remotion/google-fonts/HindSiliguri";
import { loadFont as loadArabic } from "@remotion/google-fonts/Amiri";

const bn = loadBengali("normal", {
  weights: ["500", "700"],
  subsets: ["bengali", "latin"],
});
const ar = loadArabic("normal", {
  weights: ["400", "700"],
  subsets: ["arabic", "latin"],
});

export const theme = {
  // স্কিম ২: মধ্যরাতের নীল-সোনালি
  colors: {
    bg: "#0A1330",
    bgDeep: "#050A1E",
    bgAlt: "#111C45",
    hero: "#4A74FF",
    accent: "#F2C76E",
    text: "#F5F7FF",
    textDim: "#AEB8DC",
    muted: "#6874A3",
    glow: "rgba(74, 116, 255, 0.45)",
    accentGlow: "rgba(242, 199, 110, 0.35)",
    glass: "rgba(255, 255, 255, 0.06)",
    glassStrong: "rgba(255, 255, 255, 0.10)",
    glassBorder: "rgba(255, 255, 255, 0.16)",
  },
  fonts: {
    bn: bn.fontFamily,
    ar: ar.fontFamily,
  },
  radius: { card: 40, chip: 28, pill: 999 },
  shadow: {
    card: "0 40px 80px -20px rgba(0,0,0,0.6)",
    soft: "0 18px 40px -16px rgba(0,0,0,0.5)",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  // শান্ত, গম্ভীর মোশন-ব্যক্তিত্ব
  spring: {
    snappy: { damping: 15, stiffness: 150, mass: 0.7 },
    smooth: { damping: 22, stiffness: 90, mass: 1 },
    bouncy: { damping: 12, stiffness: 150, mass: 0.8 },
  },
  size: {
    arabicHero: 112,
    arabicMid: 92,
    bnHero: 56,
    bnMid: 48,
    pill: 38,
  },
  // সাউন্ড: ভলিউম (০.২–০.৩৫) ও দৈর্ঘ্য (সেকেন্ড)
  sfx: {
    pop: { volume: 0.32, seconds: 0.3 },
    whoosh: { volume: 0.28, seconds: 0.8 },
    click: { volume: 0.3, seconds: 0.2 },
    chime: { volume: 0.26, seconds: 0.65 },
    thud: { volume: 0.26, seconds: 0.5 },
  },
} as const;

export type SfxName = keyof typeof theme.sfx;
